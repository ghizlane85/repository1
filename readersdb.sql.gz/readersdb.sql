-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 18 Août 2017 à 14:52
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `readersdb`
--

-- --------------------------------------------------------

--
-- Structure de la table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `abstract` text NOT NULL,
  `comments` text NOT NULL,
  `owner` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `book`
--

INSERT INTO `book` (`id`, `title`, `author`, `category`, `image`, `abstract`, `comments`, `owner`) VALUES
(1, 'Par orgueil', 'laurent', '0', 'https://images-na.ssl-images-amazon.com/images/I/51FMm6dkQmL._SX307_BO1,204,203,200_.jpg', 'Comment se faire aimer d''une femme avec qui on a toujours été odieux ? Depuis l''adolescence, le vicomte de Hastings est fou d''Helena Fitzhugh. Face à son indifférence, il s''est construit par orgueil un personnage grossier et arrogant qu''elle juge insupportable. Sa tendresse va ailleurs, vers un érudit falot qui, bien que marié, n''a pas l''énergie de lui résister. Le jour où le scandale va éclater, Hastings sauve la réputation d''Helena en la contraignant au mariage. Le voici désormais l''époux d''une femme qui le hait. Et pour lire enfin l''amour dans ses yeux, il faudrait un miracle...', '', 'oualid'),
(2, 'Le code de la conscience ', 'Stanislas Dehaene ', 'science', 'https://static.fnac-static.com/multimedia/Images/FR/NR/8a/b1/5e/6205834/1540-1/tsp20141202100729/Le-code-de-la-conscience.jpg', 'D''où viennent nos perceptions, nos sentiments, nos illusions etnos rêves ? Où s''arrête le traitement mécanique de l''informationet où commence la prise de conscience ? L''esprit humain est-ilsuffisamment ingénieux pour comprendre sa propre existence ?La prochaine étape sera-t-elle une machine consciente de sespropres limites ?Depuis plus de vingt ans, Stanislas Dehaene analyse les méca-nismes de la pensée humaine. Dans ce livre, il invite le lecteur dansson laboratoire où d''ingénieuses expériences visualisent l''incons-cient et démontent les bases biologiques de la conscience.Grâce à l''imagerie cérébrale et même à des électrodes intro-duites dans la profondeur du cortex, nous commençons enfin àcomprendre les algorithmes qui nous font penser.Détecter la présence de la conscience, décoder à quoi penseun individu, un bébé ou même un animal, sortir les patientsdu coma, doter les machines d''un début de conscience...LeCode de la conscienceouvre d''extraordinaires perspectivespratiques et intellectuelles,en accordant une importanceégale aux implications technologiques, philosophiques,personnelles et éthiques de la résolution du dernier desmystères.', '', 'ghizlane'),
(3, 'Libérez votre cerveau', ' Idriss ABERKANE ', '0', 'https://static.fnac-static.com/multimedia/Images/FR/NR/a7/a8/77/7841959/1507-1/tsp20161006130737/Liberez-votre-cerveau-.jpg', 'Notre cerveau est plus grand que toutes ses créations. Ce n’est pas à notre cerveau de s’adapter à nos créations, mais l’inverse. De la médecine à la politique, du marketing à l’éducation, appliquer ce principe, c’est se changer soi-même... et changer le monde. Notre société brasse aujourd’hui une quantité gigantesque de connaissances et, malgré tout, ne produit que très peu de sagesse. Or une civilisation qui produit beaucoup de savoirs sans sagesse est vouée à l’autodestruction. L’ouvrage traite en particulier de la neuroergonomie, la science qui étudie le cerveau au travail. De l’école au bureau, ou en ville, le potentiel de cette nouvelle science est immense, aussi bien socialement qu’économiquement. Il décrit précisément notre cerveau, ses capacités, ses limites, ses points aveugles, et les moyens connus de l’utiliser au mieux. Des cas récents nous démontrent en effet à quel point l’usage de notre cerveau est perfectible : des calculateurs prodiges parviennent à calculer la racine treizième d’un nombre à cent chiffres en moins de quatre secondes. Or ils ont le même cerveau que nous ! La différence réside donc dans leur manière de l’utiliser, et en particulier dans leur capacité à répartir la charge cognitive sur plusieurs fonctions de leur esprit.\r\n\r\nCette capacité, Idriss Aberkane nous explique comment nous pourrions tous la maîtriser.', '', 'ghizlane'),
(6, 'La peste', 'Albert Camus', '1', 'http://ecx.images-amazon.com/images/I/51DNiBasN9L.jpg', 'Oran, un jour d''avril 194. , le docteur Rieux découvre le cadavre d''un rat sur son palier. Le concierge, monsieur Michel, pense que ce sont des mauvais plaisants qui s''amusent à déposer ces cadavres de rats dans son immeuble. A midi, Rieux accompagne à la gare son épouse qui, malade, part se soigner dans une ville voisine. Quelques jours plus tard, une agence de presse annonce que plus de six mille rats ont été ramassés le jour même. L''angoisse s''accroît . Quelques personnes commencent à émettre quelques récriminations contre la municipalité. Puis , soudainement, le nombre de cadavres diminue, le rues retrouvent leur propreté, la ville se croit sauvée. \r\n\r\n', '', 'toto'),
(10, ' La touche étoile', ' 	Benoîte Groult', '1', 'http://ecx.images-amazon.com/images/I/41SPO3pJ1DL.jpg', ' il fait beau', '', 'ghizlane');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'littérature'),
(2, 'science'),
(3, 'divers'),
(4, 'aventure');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`) VALUES
(1, 'oualid', 'oualid@exemple.com', 'oualid'),
(2, 'ghizlane', 'ghizlane@exemple.com', 'ghizlane'),
(3, 'laurent', 'laurent@example.com', 'lolo'),
(4, 'momo', 'momo@example.com', 'momo'),
(5, 'momo', 'momo@example.com', 'momo'),
(6, 'yousra', 'yousra@exemple.com', 'yoyo'),
(7, 'yousra', 'yousra@exemple.com', 'yoyo'),
(8, 'yousra', 'yousra@exemple.com', 'yoyo'),
(9, 'yousra', 'yousra@exemple.com', 'yoyo');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
